/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author anisacallis
 */
public class LoginPage extends JPanel {

    private static final long serialVersionUID = -337449186297669567L;
    private JLabel user_label = new JLabel("Username: ");
    private JLabel password_label = new JLabel("Password: ");
    private JLabel screenName = new JLabel("Welcome to Plan & Earn: Please login below",SwingConstants.CENTER);
    private JTextField username = new JTextField(10);
    private JTextField password = new JTextField(10);
    private JButton login, cancel, classList;
    private JPanel panel = new JPanel();
    private String hidden = "login";
    
    Credentials c;
    private Controller cp;
    public LoginPage(Credentials c, Controller cp) {
        this.c = c;
        this.cp = cp;
        setLayout(new GridLayout(0, 1));
        add(screenName);
        screenName.setFont(new Font("Serif", Font.PLAIN, 18));
        add(user_label);
        add(username);
        add(password_label);
        add(password);
        login = new JButton("LOGIN");
        setVisible(true);
        addToggleListener(cp);
      initialize();
      setBackground(Color.PINK);
    }
public void initialize(){
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel);
        c.weightx = 0.6;
        c.weighty = 0.6;
        c.gridx = 1;
        c.gridy = 1;
        
        c.fill = GridBagConstraints.NONE;
        c.insets = new Insets(10, 50, 10, 20);

        login.setPreferredSize(new Dimension(100,50));

        c.anchor = GridBagConstraints.SOUTHEAST;
        buttonPanel.add(login,c);
        buttonPanel.setBackground(Color.PINK);
    }
    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }
    
    
    public void addToggleListener(ActionListener al){
        login.addActionListener(al);
    }

    public void addToggleListener(Controller cp) {
      login.addActionListener(new ActionListener(){
          @Override
          public void actionPerformed(ActionEvent e){
       if(hidden.equals("login")){
            String usn = username.getText();
            String psd = password.getText();
            if(c.loginInfo.containsKey(usn) && c.loginInfo.containsValue(psd)){
                cp.setHomePageVisible();
            }
              }
          }
    });
    }
}
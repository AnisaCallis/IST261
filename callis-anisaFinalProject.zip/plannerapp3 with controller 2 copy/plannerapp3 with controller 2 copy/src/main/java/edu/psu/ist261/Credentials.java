/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author anisacallis
 */
public class Credentials{
    Controller cp;
    Credentials c;
    public Map<String, String> loginInfo = new HashMap<String,String>();
    
    public Map<String, String> getLoginInfo() {
        return loginInfo;
    }
    
    public void addLoginInfo(String userName, String password) {
        loginInfo.put(userName, password);
        System.out.println(loginInfo);
       
    }
    
    @Override
    public String toString(){
        return " Username and password= " + loginInfo;
    }
}

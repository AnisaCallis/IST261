/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.psu.ist261;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 *
 * @author anisa
 */
public class AddTasks extends JPanel {

    JButton addTask;
    private JButton Home;
    private JButton viewList;
    private JLabel screenName = new JLabel("Task Creater: Add Task, Then View To-do List", SwingConstants.CENTER);
    private JTextArea addedTasks = new JTextArea();
    private JPanel panel;
    private String hidden = "add task";
    private String h = "Home";
    private String v = "view list";
    private Controller cp;
    List<ToDoListInfo> tasks;

    public AddTasks(Controller cp, List<ToDoListInfo> tasks) {
        this.cp = cp;
        this.tasks = tasks;
        setLayout(new BorderLayout());
        setBackground(Color.ORANGE);
        add(screenName, BorderLayout.NORTH);
         screenName.setFont(new Font("Serif", Font.PLAIN, 23));
        addTask = new JButton("Add task");
        Home = new JButton("Home");
        viewList = new JButton("View to-do list");
        setVisible(false);
        addToggleListener();
        initialize();
    }

    public void initialize() {
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 50, 10, 20);
        viewList.setPreferredSize(new Dimension(100, 50));
        c.anchor = GridBagConstraints.NORTH;
        buttonPanel.add(viewList, c);
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 50, 10, 20);
        addTask.setPreferredSize(new Dimension(100, 50));
        c.anchor = GridBagConstraints.NORTHWEST;
        buttonPanel.add(addTask, c);
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 50, 10, 20);
        Home.setPreferredSize(new Dimension(100, 50));
        c.anchor = GridBagConstraints.NORTHWEST;
        buttonPanel.add(Home, c);
        buttonPanel.setBackground(Color.ORANGE);
    }

    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }

    public void addToggleListener(ActionListener al) {
        addTask.addActionListener(al);
        Home.addActionListener(al);
        viewList.addActionListener(al);
    }

    public void setTasks(ToDoListInfo enteredTasks) {
        this.tasks = tasks;
        addedTasks.append(enteredTasks.toString());
    }

    public void addToggleListener() {
        addTask.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (hidden.equals("add task")) {
                    cp.setToDoListBuilderVisible();
                } else {
                    panel.setVisible(true);
                }
            }
        });
        Home.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (h.equals("Home")) {
                    cp.setHomePageVisible();
                } else {
                    panel.setVisible(true);
                }
            }
        });
        viewList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (v.equals("view list")) {
                    cp.setAddedTasksVisible();
                    //}
                } else {
                    panel.setVisible(true);
                }
            }
        });
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author anisacallis
 */
class HomePage extends JPanel {

    private JButton classList;
    //private JButton test;
    private JLabel screenName = new JLabel("Welcome to Plan & Earn", SwingConstants.CENTER);
    private Controller cp;
    private JPanel panel;
    private JButton toDoList;
    private JButton rewards;
    private String hidden = "classList";
    private String t = "to-do list";
    private String r = "rewards";

    public HomePage(Controller cp) {
        //setLayout(new BorderLayout());
        this.cp = cp;
        setBackground(Color.ORANGE);
        setLayout(new BorderLayout());
        add(screenName, BorderLayout.NORTH);
        screenName.setFont(new Font("Serif", Font.PLAIN, 23));
        classList = new JButton("Class List");
        toDoList = new JButton("To-do List");
        rewards = new JButton("Rewards");
        setVisible(false);
        addToggleListener();
        initialize();
    }

    public void initialize() {
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel);
        
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 50, 10, 20);
        classList.setPreferredSize(new Dimension(100,50));
        c.anchor = GridBagConstraints.NORTHWEST;
        buttonPanel.add(classList, c);
        
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        toDoList.setPreferredSize(new Dimension(100,50));
        c.anchor = GridBagConstraints.NORTHWEST;
        buttonPanel.add(toDoList, c);
        
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        rewards.setPreferredSize(new Dimension(100,50));
        c.anchor = GridBagConstraints.NORTHWEST;
        buttonPanel.add(rewards, c);
        buttonPanel.setBackground(Color.ORANGE);
    }

    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }

    private void addToggleListener(ActionListener al) {
        classList.addActionListener(al);
        toDoList.addActionListener(al);
        rewards.addActionListener(al);
    }

    public void addToggleListener() {
        classList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (hidden.equals("classList")) {
                    cp.setClassListVisible();
                } else {
                    panel.setVisible(true);
                }
            }
        });
        toDoList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (t.equals("to-do list")) {
                    cp.setTaskListVisible();
                }
            }

        });
        rewards.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (r.equals("rewards")) {
                    cp.setRewardsListVisible();
                }
            }

        });
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.psu.ist261;

/**
 *
 * @author anisa
 */
public class ToDoListInfo {
    private String task;
    private String classAssignedIn;
    private String notes; 
    private String dueDate; 
    public ToDoListInfo(String task,String classAssignedIn, String notes, String dueDate){
        this.task = task;
        this.classAssignedIn = classAssignedIn;
        this.notes = notes; 
        this.dueDate = dueDate; 
    }
    public String getTask() {
        return task;
    }
    public void setTask(String task) {
        this.task = task;
    }
    public String getClassAssignedIn() {
        return classAssignedIn;
    }
    public void setClassAssignedIn(String classAssignedIn) {
        this.classAssignedIn = classAssignedIn;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    @Override
    public String toString() {
        return "ToDoListInfo{ \n task=" + task + "\n" + " classAssignedIn=" + classAssignedIn + "\n" + " notes=" + notes + "\n" + " dueDate=" + dueDate + "\n" + '}';
    }
    
}

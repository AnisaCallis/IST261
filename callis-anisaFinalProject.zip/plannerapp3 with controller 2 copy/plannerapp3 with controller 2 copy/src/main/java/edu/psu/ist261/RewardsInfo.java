/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.psu.ist261;


/**
 *
 * @author anisa
 */
public class RewardsInfo {
    private int currentRewardAmount;
    private String possibleReward;
    private int rewardAmount;
    public RewardsInfo(int currentRewardAmount, String possibleReward, int rewardAmount){
        this.currentRewardAmount = currentRewardAmount;
        this.possibleReward = possibleReward;
        this.rewardAmount = rewardAmount;
    }

    public int getCurrentRewardAmount() {
        return currentRewardAmount;
    }

    public void setCurrentRewardAmount(int currentRewardAmount) {
        this.currentRewardAmount = currentRewardAmount;
    }

    public String getPossibleReward() {
        return possibleReward;
    }

    public void setPossibleReward(String possibleReward) {
        this.possibleReward = possibleReward;
    }

    public int getRewardAmount() {
        return rewardAmount;
    }

    public void setRewardAmount(int rewardAmount) {
        this.rewardAmount = rewardAmount;
    }

    @Override
    public String toString() {
        return "RewardsInfo{ \n currentRewardAmount=" + currentRewardAmount + "\n" + " possibleReward=" + possibleReward + "\n" + " rewardAmount=" + rewardAmount + '}';
    }
    
}

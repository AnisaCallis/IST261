package edu.psu.ist261;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.util.TypeLiteral;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
public class Main {

    public static void main(String[] args) {
       Credentials c = new Credentials();
        List<ClassInfo> classes = new ArrayList<>();
        List<ToDoListInfo> tasks = new ArrayList<>();
        List<RewardsInfo> rewards = new ArrayList<>();
       List<Student> studentList = new ArrayList<>();
       addAnisa(studentList, c, classes, tasks,rewards);
       Controller cp = new Controller(c,classes,tasks,rewards); 
        Jsonb jsonb = JsonbBuilder.create();
        String jsonStudent = jsonb.toJson(studentList);
        java.lang.reflect.Type t = new TypeLiteral<List<Student>>(){}.getType();
        List<Student> l2 = jsonb.fromJson(jsonStudent, t);
        String homeDirectory = System.getProperty("user.home");
        Path p = Paths.get(homeDirectory + "/NetBeansProjects");
        if(!Files.exists(p)){
            File f = new File(homeDirectory + "/NetBeansProjects");
            if(!f.mkdir()){
                System.out.println("Nope");
            }
        }   
        String s = homeDirectory + "/NetBeansProjects/studentInfo.json";
        p = Paths.get(s);
        File f2 = new File(s); 
        try{
            System.out.println("writing out file");
            System.out.println(f2.getAbsoluteFile());
            FileWriter fw = new FileWriter(f2.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(jsonStudent);
            bw.close();
        }
        catch(IOException e){
            e.printStackTrace();
            System.exit(-1);
        }
    }
    private static void addAnisa(List<Student> list, Credentials c, List<ClassInfo> classes, List<ToDoListInfo> tasks, List<RewardsInfo> rewards){
        Student s = new Student(c,classes);
        
        s.setFirstName("Anisa");
        s.setLastName("Callis");
         c.addLoginInfo("amc123", "demo2021");
         classes.add(new ClassInfo("Introduction to Application Development ", "IST 261 ", "MWF ", "9 - 10 am "));
         classes.add(new ClassInfo("Networking ", "IST 220 ", "TueTh ", "1:30 - 3 pm "));
         tasks.add(new ToDoListInfo("Create network diagram ","IST 220 ","Must fit on one page ", "Due on 12/12/2021 "));
         rewards.add(new RewardsInfo(150,"Amazon Gift Card", 25));
        list.add(s);
        System.out.println(list);
    }

}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

/**
 *
 * @author anisacallis
 */
public class ViewAddedClasses extends JPanel {

    private static final long serialVersionUID = -337449186297669567L;
    private JLabel screenName = new JLabel("Added Classes", SwingConstants.CENTER);
    private JTextArea addedClassList = new JTextArea();
    private JButton moreClasses;
    private JButton ClassList;
    private String hidden = "add another class";
    private String cl = "ClassList";
    private JPanel panel = new JPanel();
    ClassInfo classes;
    Controller cp;

    public ViewAddedClasses(Controller cp, ClassInfo classes) {
        this.cp = cp;
        this.classes = classes;
        setLayout(new GridLayout(0, 1));
       setBackground(Color.ORANGE);
        add(screenName);
         screenName.setFont(new Font("Serif", Font.PLAIN, 23));
        add(addedClassList);
        addedClassList.append(classes.toString());
        moreClasses = new JButton("Add another class");
        ClassList = new JButton("Class List Home");
        setVisible(false);
        addToggleListener(cp);
        initialize();
    }

    public void initialize() {
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel);
        c.weightx = 0.6;
        c.weighty = 0.6;
        c.gridx = 1;
        c.gridy = 1;
        c.fill = GridBagConstraints.NONE;
        c.insets = new Insets(10, 50, 10, 20);
        ClassList.setPreferredSize(new Dimension(200, 50));
        c.anchor = GridBagConstraints.SOUTHEAST;
 
        buttonPanel.add(ClassList, c);
        buttonPanel.setBackground(Color.ORANGE);
    }

    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }

    public void setClasses(ClassInfo enteredClass) {
        this.classes = enteredClass;
        addedClassList.setText("");
        addedClassList.append(enteredClass.toString());
    }

    public void addToggleListener(ActionListener al) {
        moreClasses.addActionListener(al);
        ClassList.addActionListener(al);
    }

    public void addToggleListener(Controller cp) {
        ClassList.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    if(cl.equals("ClassList")){
                        cp.setClassListVisible();
                    } else {
                        panel.setVisible(true);
                    }
                }
            });
    }
}

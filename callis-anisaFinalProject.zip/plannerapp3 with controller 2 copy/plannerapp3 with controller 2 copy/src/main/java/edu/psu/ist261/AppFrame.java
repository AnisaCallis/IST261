/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;

import java.awt.Color;
import javax.swing.*;

/**
 *
 * @author anisacallis
 */
public class AppFrame extends JFrame {
    private static final long serialVersionUID = -337449186297669567L;

    public AppFrame(){
        setTitle("Plan & Earn");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBackground(Color.blue);
    }
}

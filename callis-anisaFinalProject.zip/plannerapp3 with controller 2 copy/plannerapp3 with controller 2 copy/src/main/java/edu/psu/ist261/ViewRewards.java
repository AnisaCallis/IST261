/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.psu.ist261;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 *
 * @author anisa
 */
public class ViewRewards extends JPanel{
    private static final long serialVersionUID = -337449186297669567L;
    private JLabel screenName = new JLabel("Available Rewards", SwingConstants.CENTER);
    private JTextArea availableRewards = new JTextArea();
    private JButton redeem;
    private JButton home; 
    private String hidden = "redeem";
    private String h = "home";
    private JPanel panel = new JPanel();
    List<RewardsInfo> rewards;
    Controller cp; 
    public ViewRewards(Controller cp, List<RewardsInfo> rewards){
        this.cp = cp;
        this.rewards = rewards;
        setLayout(new GridLayout(0,1));
        add(screenName);
         screenName.setFont(new Font("Serif", Font.PLAIN, 23));
        setBackground(Color.ORANGE);
        add(availableRewards);
        availableRewards.append(rewards.toString());
        redeem = new JButton("Redeem Rewards");
        home = new JButton("Home Page");
        setVisible(false);
        addToggleListener(cp);
        initialize();
    }
    public void initialize(){
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel);
         c.weighty = 0.6;
        c.gridx = 1;
        c.gridy = 1;
        c.fill = GridBagConstraints.NONE;
        c.insets = new Insets(10, 50, 10, 20);
        home.setPreferredSize(new Dimension(200, 50));
        c.anchor = GridBagConstraints.SOUTHEAST;
        
        buttonPanel.add(home, c);
        c.weightx = 0.6;
        c.weighty = 0.6;
        c.gridx = 1; 
        c.gridy = 1;
        c.fill= GridBagConstraints.NONE; 
        c.insets = new Insets(10,50,10,20);
        redeem.setPreferredSize(new Dimension(200,50));
        c.anchor = GridBagConstraints.SOUTHWEST; 
        buttonPanel.add(redeem,c);
        buttonPanel.setBackground(Color.ORANGE);
    }
    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }
    public void SetRewards(RewardsInfo enteredReward){
        this.rewards = rewards;
        availableRewards.append(enteredReward.toString());
    }
    public void addToggleListener(ActionListener al) {
        redeem.addActionListener(al);
        home.addActionListener(al);
    }
    public void addToggleListener(Controller cp){
        redeem.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(hidden.equals("redeem")){
                    for(int i = 0; i < rewards.size(); i++){
                        int newCurrentRewards = rewards.get(i).getCurrentRewardAmount() + rewards.get(i).getRewardAmount();
                        rewards.get(i).setCurrentRewardAmount(newCurrentRewards);
                        rewards.get(i).setRewardAmount(0);
                        availableRewards.setText("");
                        availableRewards.append(rewards.toString());
                    }
                }
            }
        });
        home.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    if(h.equals("home")){
                        cp.setHomePageVisible();
                    } else {
                        panel.setVisible(true);
                    }
                }
            });
    }
}

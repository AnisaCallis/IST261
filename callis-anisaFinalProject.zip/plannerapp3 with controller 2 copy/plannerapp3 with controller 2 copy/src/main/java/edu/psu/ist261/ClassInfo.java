/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;


/**
 *
 * @author anisacallis
 */
public class ClassInfo {
    private String className;
    private String classNumber; 
    private String classTime;
    private String classDays;
//    private List<String> classDetails = new ArrayList<String>();
    
    
    public ClassInfo(String className, String classNumber, String classDays, String classTime){
        this.className = className; 
        this.classNumber = classNumber; 
        this.classDays = classDays; 
        this.classTime = classTime;
    }
    

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    public String getClassTime() {
        return classTime;
    }

    public void setClassTime(String classTime) {
        this.classTime = classTime;
    }

    public String getClassDays() {
        return classDays;
    }

    public void setClassDays(String classDays) {
        this.classDays = classDays;
    }
    @Override 
    public String toString(){
        return "Class details= " + "Classname:" + getClassName() + "\n" + " ClassNumber:" + getClassNumber() + "\n" + " classDays:" + getClassDays() + "\n" + " ClassTime:" + getClassTime();
}
}


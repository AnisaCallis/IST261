/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.util.List;
import javax.swing.JPanel;

/**
 *
 * @author anisacallis
 */
public class Controller {

    AppFrame frame = new AppFrame();
    Credentials c;
    List<ClassInfo> classes;
    List<ToDoListInfo> tasks;
    List<RewardsInfo> rewards;
    ClassInfo currentClass = new ClassInfo("test","test","test","test");
    ToDoListInfo currentTask = new ToDoListInfo("Add Task", "Add class", "Add notes","Add due date");
    RewardsInfo currentReward = new RewardsInfo(0,"blank",0);
    LoginPage lp;
    HomePage hp;
    AddClasses addClass;
    AddTasks addTask;
    ScheduleBuilder sb;
    ViewAddedClasses vac;
    ToDoListBuilder tdl;
    ViewToDoList vl;
    ViewRewards vr;
    private final CardLayout cl;
    private final JPanel mainPanel;
    private final String loginPage = "login";
    private final String homePage = "Homepage";
    private final String classPage = "classList";
    private final String taskPage = "taskList";
    private final String schedulePage = "schedule";
    private final String classListPage = "view classes";
    private final String addTaskPage = "add tasks";
    private final String toDoListPage = "view to-do list";
    private final String rewardsPage = "view rewards";
    public Controller(Credentials c, List<ClassInfo> classes, List<ToDoListInfo> tasks,List<RewardsInfo> rewards) {
        this.c = c;
        this.classes = classes;
        this.tasks = tasks;
        this.rewards = rewards;
        lp = new LoginPage(c, this);
        hp = new HomePage(this);
        addClass = new AddClasses(this,classes);
        addTask = new AddTasks(this,tasks);
        sb = new ScheduleBuilder(this, classes);
        vac = new ViewAddedClasses(this,currentClass);
        tdl = new ToDoListBuilder(this, tasks);
        vl = new ViewToDoList(this,currentTask);
        vr = new ViewRewards(this,rewards);
      
      
        mainPanel = new JPanel();
        cl = new CardLayout();
        mainPanel.setLayout(cl);
        frame.setLayout(new BorderLayout());
        frame.add(mainPanel, BorderLayout.CENTER);
        mainPanel.add(loginPage, lp);
        mainPanel.add(homePage, hp);
        mainPanel.add(classPage, addClass);
        mainPanel.add(taskPage, addTask);
        mainPanel.add(schedulePage, sb);
        mainPanel.add(classListPage, vac);
        mainPanel.add(addTaskPage, tdl);
        mainPanel.add(toDoListPage, vl);
        mainPanel.add(rewardsPage, vr);
        frame.setVisible(true);
    }

    public void setHomePageVisible() {
        cl.show(mainPanel, homePage);
    }

    public void setClassListVisible() {
        cl.show(mainPanel, classPage);
    }
    public void setTaskListVisible(){
        cl.show(mainPanel, taskPage);
    }
    public void SetScheduleBuilderVisible() {
        cl.show(mainPanel, schedulePage);
    }
    public void SetAddedClassesVisible(){
        cl.show(mainPanel,classListPage);
    }
    public void setAddedTasksVisible(){
        cl.show(mainPanel, toDoListPage);
    }
    public void setToDoListBuilderVisible(){
        cl.show(mainPanel, addTaskPage);
    }
    public void setRewardsListVisible(){
        cl.show(mainPanel, rewardsPage);
    }
    public void setCurrentClass(ClassInfo currentClass){
        this.currentClass = currentClass;
        vac.setClasses(currentClass);
    }
    public void setCurrentTask(ToDoListInfo currentTask){
        this.currentTask = currentTask;
        vl.setTasks(this.currentTask);
    }
    public void setCurrentReward(RewardsInfo currentReward){
        this.currentReward = currentReward;
        vr.SetRewards(currentReward);
        
    }
}

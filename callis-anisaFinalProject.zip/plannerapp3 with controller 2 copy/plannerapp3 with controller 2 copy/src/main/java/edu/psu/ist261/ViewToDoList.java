/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.psu.ist261;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 *
 * @author anisa
 */
public class ViewToDoList extends JPanel {
    private static final long serialVersionUID = -337449186297669567L;
     private JLabel screenName = new JLabel("Your To-do list",SwingConstants.CENTER);
     private JTextArea addedTasks = new JTextArea(); 
     private JButton moreTasks; 
     private JButton toDoList;
     private String hidden = "add another task";
     private String tdl = "toDoList";
     private JPanel panel = new JPanel(); 
     ToDoListInfo tasks;
     Controller cp;
     public ViewToDoList(Controller cp, ToDoListInfo tasks){
         this.cp = cp; 
         this.tasks = tasks;
         setLayout(new GridLayout(0,1));
         setBackground(Color.ORANGE);
         add(screenName); 
          screenName.setFont(new Font("Serif", Font.PLAIN, 23));
         add(addedTasks);
         addedTasks.append(tasks.toString());
         moreTasks = new JButton("Add another task");
         toDoList = new JButton("ToDo List Home");
         setVisible(false);
         addToggleListener(cp);
         initialize();
     }
     public void initialize(){
         JPanel buttonPanel = new JPanel(new GridBagLayout()); 
         GridBagConstraints c = new GridBagConstraints();
         add(buttonPanel); 
         c.weightx = 0.6;
         c.weighty = 0.6;
         c.gridx = 1;
         c.gridy = 1;
         c.fill= GridBagConstraints.NONE;
         c.insets = new Insets(10,50,10,20);
         toDoList.setPreferredSize(new Dimension(200,50));
         c.anchor = GridBagConstraints.SOUTHEAST;
         buttonPanel.add(toDoList, c);
         buttonPanel.setBackground(Color.ORANGE);
     }
      public void setText(String s) {
        screenName.setText(s);
    }
    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }
    public void setTasks(ToDoListInfo enteredTasks){
        this.tasks = tasks; 
        addedTasks.setText("");
        addedTasks.append(enteredTasks.toString());
    }
    public void addToggleListener(ActionListener al){
        moreTasks.addActionListener(al);
        toDoList.addActionListener(al);
    }
    public void addToggleListener(Controller cp){
        toDoList.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    if(tdl.equals("toDoList")){
                        cp.setTaskListVisible();
                    } else {
                        panel.setVisible(true);
                    }
                }
            });
    }
}

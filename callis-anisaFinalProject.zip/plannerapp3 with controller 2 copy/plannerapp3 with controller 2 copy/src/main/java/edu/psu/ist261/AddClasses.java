/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 *
 * @author anisacallis
 */
public class AddClasses extends JPanel{
    private JButton addClass; 
    private JButton Home;
     private JButton viewList;
    private JLabel screenName = new JLabel("Class Schedule: Add Class, Then view class list. ",SwingConstants.CENTER);
    private JTextArea addedClassList = new JTextArea();
    private JPanel panel; 
    private String hidden = "addClass";
    private String h = "Home";
    private String v = "view list";
    private Controller cp;
    List<ClassInfo> classes;
    public AddClasses(Controller cp, List<ClassInfo> classes) {
        this.cp = cp;
        this.classes = classes;
        //setBorder(BorderFactory.createEtchedBorder());
        
        setLayout(new BorderLayout());
        add(screenName, BorderLayout.NORTH);
        setBackground(Color.ORANGE);
         screenName.setFont(new Font("Serif", Font.PLAIN, 23));
        addClass = new JButton("AddClass");
        Home = new JButton("Home");
        viewList = new JButton("View class list");
        setVisible(false);
        addToggleListener();
        initialize();
    }
    public void initialize(){
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel);
         c.weightx = 0.5;
        c.gridx = 1; 
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 50, 10, 20);
        viewList.setPreferredSize(new Dimension(100,50));
        c.anchor = GridBagConstraints.NORTHEAST;
        buttonPanel.add(viewList, c);
        c.gridx = 0; 
        c.gridy = 0;
        c.fill= GridBagConstraints.HORIZONTAL; 
        c.insets = new Insets(10,50,10,20);
        addClass.setPreferredSize(new Dimension(100,50));
        c.anchor = GridBagConstraints.NORTHWEST; 
        buttonPanel.add(addClass,c);
         c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 50, 10, 20);
        Home.setPreferredSize(new Dimension(100, 50));
        c.anchor = GridBagConstraints.NORTHWEST;
        buttonPanel.add(Home, c);
buttonPanel.setBackground(Color.ORANGE);
    }
    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }
    public void addToggleListener(ActionListener al) {
       addClass.addActionListener(al);
       Home.addActionListener(al);
    }
    public void setClasses(ClassInfo enteredClasses){
        this.classes = classes;
        addedClassList.append(enteredClasses.toString());
    }
    public void addToggleListener(){
        addClass.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(hidden.equals("addClass")){
                    System.out.println("work please!");
                    cp.SetScheduleBuilderVisible();
                } else {
                    panel.setVisible(true);
                }
            } 
        });
        Home.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    if(h.equals("Home")){
                        cp.setHomePageVisible();
                    } else {
                        panel.setVisible(true);
                    }
                }
            });
        viewList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (v.equals("view list")) {
                    System.out.println("this shoud show the task.");
                    cp.SetAddedClassesVisible();
                    //}
                } else {
                    panel.setVisible(true);
                }
            }
        });
    }
}

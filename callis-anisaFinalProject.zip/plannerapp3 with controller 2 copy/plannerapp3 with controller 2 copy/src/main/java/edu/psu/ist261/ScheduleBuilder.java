/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author anisacallis
 */
public class ScheduleBuilder extends JPanel {

    private static final long serialVersionUID = -337449186297669567L;
    private JLabel name_label = new JLabel("Class Name: ");
    private JLabel class_number = new JLabel("Class Number: ");
    private JLabel class_time = new JLabel("Class Time: ");
    private JLabel class_days = new JLabel("Class Days: ");
    private JLabel screenName = new JLabel("Schedule Builder: Leave a space after each entry", SwingConstants.CENTER);
    private JTextField name = new JTextField(10);
    private JTextField number = new JTextField(10);
    private JTextField time = new JTextField(10);
    private JTextField days = new JTextField(10);
    private JButton add;
    private JButton Home;
    private JPanel panel = new JPanel();
    private String hidden = "add class";
    private String h = "home";
    List<ClassInfo> classes;
    private Controller cp;
    public ScheduleBuilder(Controller cp, List<ClassInfo> classes) {
        this.cp = cp;
        this.classes = classes;
        setLayout(new GridLayout(0, 1));
        setBackground(Color.ORANGE);
        add(screenName);
         screenName.setFont(new Font("Serif", Font.PLAIN, 23));

        add(name_label);
        add(name);
        add(class_number);
        add(number);
        add(class_time);
        add(time);
        add(class_days);
        add(days);

        //this.login = login;
        add = new JButton("Add");
        Home = new JButton("Home");
        setVisible(false);
        addToggleListener(cp);
        initialize();
    }

    public void initialize() {
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel);
        c.weightx = 0.6;
        c.weighty = 0.6;
        c.gridx = 1;
        c.gridy = 1;

        c.fill = GridBagConstraints.NONE;
        c.insets = new Insets(10, 50, 10, 20);

        Home.setPreferredSize(new Dimension(100, 50));

        c.anchor = GridBagConstraints.SOUTHEAST;
        buttonPanel.add(Home, c);
        c.weightx = 0.6;
        c.weighty = 0.6;
        c.gridx = 1;
        c.gridy = 1;

        c.fill = GridBagConstraints.NONE;
        c.insets = new Insets(10, 50, 10, 20);

        add.setPreferredSize(new Dimension(100, 50));

        c.anchor = GridBagConstraints.NORTHWEST;
        buttonPanel.setBorder(BorderFactory.createEtchedBorder());
        buttonPanel.add(add, c);
        buttonPanel.setBackground(Color.ORANGE);
    }

    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }

    public void addToggleListener(ActionListener al) {
        add.addActionListener(al);
        Home.addActionListener(al);
    }

    public void addToggleListener(Controller cp) {
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (hidden.equals("add class")) {
                    for (int i = 0; i < classes.size(); i++) {
                        if (classes.get(i).getClassName().equals(name.getText())) {
                            if (classes.get(i).getClassNumber().equals(number.getText())) {
                                if (classes.get(i).getClassTime().equals(time.getText())) {
                                    if (classes.get(i).getClassDays().equals(days.getText())) {
                                        ClassInfo classHolder = classes.get(i);
                                        cp.setCurrentClass(classHolder);
                                        cp.SetAddedClassesVisible();
                                    }
                                }
                            }
                        }
                    }
                } else {
                    panel.setVisible(true);
                }
            }
        });
        Home.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    if(h.equals("home")){
                        cp.setHomePageVisible();
                    } else {
                        panel.setVisible(true);
                    }
                }
            });
    }
}

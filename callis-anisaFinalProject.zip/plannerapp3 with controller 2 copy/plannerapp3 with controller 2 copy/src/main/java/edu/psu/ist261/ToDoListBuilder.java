/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.psu.ist261;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author anisa
 */
public class ToDoListBuilder extends JPanel{
    private JLabel screenName = new JLabel("To-Do List Builder: Leave a space after each entry", SwingConstants.CENTER);
    private JLabel task_label = new JLabel("Task");
    private JLabel course_label = new JLabel("Class");
    private JLabel notes_label = new JLabel("Notes");
    private JLabel dueDate_label = new JLabel("Due Date");
    private JTextField task = new JTextField(10);
    private JTextField course = new JTextField(10);
    private JTextField notes = new JTextField(10);
    private JTextField dueDate = new JTextField(10);
    private JButton add;
    private JButton Home;
    private JPanel panel = new JPanel();
    private String hidden = "add task";
    private String h = "home";
    List<ToDoListInfo> tasks;
    private Controller cp; 
    public ToDoListBuilder(Controller cp,List<ToDoListInfo> tasks){
        this.cp = cp; 
        this.tasks = tasks;
        setLayout(new GridLayout(0,1));
       setBackground(Color.ORANGE);
        add(screenName);
         screenName.setFont(new Font("Serif", Font.PLAIN, 23));
        add(task_label);
        add(task);
        add(course_label);
        add(course);
        add(notes_label); 
        add(notes); 
        add(dueDate_label);
        add(dueDate);
        add = new JButton("ADD");
        Home = new JButton("HOME");
        setVisible(false);
        addToggleListener(cp);
        initialize();
    }
    public void initialize(){
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        add(buttonPanel); 
        c.weightx = 0.6;
        c.weighty = 0.6;
        c.gridx = 1; 
        c.gridy = 1;
        c.fill= GridBagConstraints.NONE; 
        c.insets = new Insets(10,50,10,20);
        add.setPreferredSize(new Dimension(100,50));
        c.anchor = GridBagConstraints.SOUTHEAST; 
        buttonPanel.add(add,c);
        c.weightx = 0.6;
        c.weighty = 0.6;
        c.gridx = 1; 
        c.gridy = 1;
        c.fill= GridBagConstraints.NONE; 
        c.insets = new Insets(10,50,10,20);
        Home.setPreferredSize(new Dimension(100,50));
        c.anchor = GridBagConstraints.NORTHWEST; 
        buttonPanel.add(Home,c);
        buttonPanel.setBackground(Color.ORANGE);
    }
    public void setText(String s) {
        screenName.setText(s);
    }

    public boolean isLabelVisible() {
        return screenName.isVisible();
    }

    public void setLabelVisibility(boolean value) {
        screenName.setVisible(value);
    }
    public void addToggleListener(ActionListener al) {
        add.addActionListener(al);
        Home.addActionListener(al);
    }
    public void addToggleListener(Controller cp){
        add.addActionListener(new ActionListener(){
           @Override 
           public void actionPerformed(ActionEvent e){
               if(hidden.equals("add task")){
                   for(int i = 0; i < tasks.size(); i++){
                       if(tasks.get(i).getTask().equals(task.getText())){
                           if(tasks.get(i).getClassAssignedIn().equals(course.getText())){
                               if(tasks.get(i).getNotes().equals(notes.getText())){
                                   if(tasks.get(i).getDueDate().equals(dueDate.getText())){
                                       ToDoListInfo taskHolder = tasks.get(i);
                                       cp.setCurrentTask(taskHolder);
                                       cp.setAddedTasksVisible();
                                       
                                   }
                               }
                           }
                       }
                   }
               } else { 
                   panel.setVisible(true);
               }
           }
        });
        Home.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e){
                    if(h.equals("home")){
                        cp.setHomePageVisible();
                    } else {
                        panel.setVisible(true);
                    }
                }
            });
    }
}
